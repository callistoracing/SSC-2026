import SwiftUI
import TipKit

@main
struct MyApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .task {
                    //For test
                    UserDefaults.standard.set(false, forKey: "hasCompletedOnboarding")
                    
                    // Configure TipKit
                    try? Tips.configure([
                        .displayFrequency(.immediate),
                        .datastoreLocation(.applicationDefault)
                    ])
                }
        }
    }
}
