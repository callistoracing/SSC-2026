import SwiftUI
import Observation
import TipKit
import NaturalLanguage // 🧠 AI Tech: Used for semantic text analysis

// MARK: - 0. TIPS CONFIGURATION

struct SubjectManagementTip: Tip {
    var title: Text { Text("Customize Your Subjects") }
    var message: Text? { Text("Tap here to add specific GCSE subjects like Art, French, or Business Studies.") }
    var image: Image? { Image(systemName: "hand.tap.fill") }
}

// MARK: - 1. GLOBAL CONSTANTS

let allGCSESubjects = [
    // Core
    "Mathematics", "English Language", "English Literature",
    "Physics", "Chemistry", "Biology",
    "Computer Science",
    // Humanities
    "History", "Geography", "Religious Studies",
    "Sociology", "Psychology", "Economics", "Business Studies",
    // Languages
    "French", "Spanish", "German", "Mandarin", "Japanese", "Latin", "Italian",
    // Arts & Others
    "Art & Design", "Music", "Drama", "Media Studies",
    "Physical Education", "Design & Technology", "Statistics"
]

// MARK: - 2. DATA MODELS

enum MBTIType: String, CaseIterable, Identifiable, Codable {
    case INTJ, INTP, ENTJ, ENTP // Analytical
    case INFJ, INFP, ENFJ, ENFP // Diplomatic
    case ISTJ, ISFJ, ESTJ, ESFJ // Sentinels
    case ISTP, ISFP, ESTP, ESFP // Explorers
    
    var id: String { self.rawValue }
    
    var color: Color {
        switch self.rawValue.first {
        case "I": return .indigo
        case "E": return .orange
        default: return .blue
        }
    }
    
    var iconName: String {
        switch self {
        case .INTJ: return "compass.drawing"; case .INTP: return "lightbulb.max.fill"; case .ENTJ: return "person.3.sequence.fill"; case .ENTP: return "bubble.left.and.bubble.right.fill"
        case .INFJ: return "hand.raised.fingers.spread.fill"; case .INFP: return "leaf.fill"; case .ENFJ: return "person.fill.star"; case .ENFP: return "flag.fill"
        case .ISTJ: return "checklist"; case .ISFJ: return "shield.fill"; case .ESTJ: return "briefcase.fill"; case .ESFJ: return "person.2.fill"
        case .ISTP: return "wrench.and.screwdriver.fill"; case .ISFP: return "paintpalette.fill"; case .ESTP: return "bolt.fill"; case .ESFP: return "music.mic"
        }
    }
    
    var description: String {
        switch self {
        case .INTJ: return "Architect"; case .INTP: return "Logician"; case .ENTJ: return "Commander"; case .ENTP: return "Debater"
        case .INFJ: return "Advocate"; case .INFP: return "Mediator"; case .ENFJ: return "Protagonist"; case .ENFP: return "Campaigner"
        case .ISTJ: return "Logistician"; case .ISFJ: return "Defender"; case .ESTJ: return "Executive"; case .ESFJ: return "Consul"
        case .ISTP: return "Virtuoso"; case .ISFP: return "Adventurer"; case .ESTP: return "Entrepreneur"; case .ESFP: return "Entertainer"
        }
    }
}

struct GCSESubject: Identifiable, Codable {
    var id = UUID()
    var name: String
    var grade: Double // 1.0 to 9.0
}

struct Recommendation: Identifiable, Codable {
    var id = UUID()
    let title: String
    let subjects: [String]
    let matchScore: Int
    let careerPath: String
    let keyReasons: [String]
    let description: String
    // Simplified for AI generation
    let mainCareerFit: String
}

// MARK: - 3. VIEW MODEL

@Observable class PathfinderViewModel {
    var selection: Int? = 0
    var gender: String = "Female"
    var hometown: String = ""
    var firstLanguage: String = "English"
    var selectedMBTI: MBTIType? = .INTJ
    
    var gcses: [GCSESubject] = [
        GCSESubject(name: "Mathematics", grade: 7),
        GCSESubject(name: "English Language", grade: 7),
        GCSESubject(name: "English Literature", grade: 7),
        GCSESubject(name: "Physics", grade: 7),
        GCSESubject(name: "Chemistry", grade: 7),
        GCSESubject(name: "Biology", grade: 7)
    ]
    
    var careerGoals: [String] = ["", "", ""]
    var activities: String = ""
    
    // UI State
    var showResults: Bool = false
    var selectedRecommendation: Recommendation?
    var isGenerating: Bool = false // ⏳ Loading State
    
    var isAboutValid: Bool { !hometown.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    var isAspirationsValid: Bool {
        !careerGoals[0].trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !activities.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    func resetData() {
        selection = 0
        hometown = ""
        gender = "Female"
        firstLanguage = "English"
        selectedMBTI = .INTJ
        careerGoals = ["", "", ""]
        activities = ""
        gcses = [
            GCSESubject(name: "Mathematics", grade: 7),
            GCSESubject(name: "English Language", grade: 7),
            GCSESubject(name: "English Literature", grade: 7),
            GCSESubject(name: "Physics", grade: 7),
            GCSESubject(name: "Chemistry", grade: 7),
            GCSESubject(name: "Biology", grade: 7)
        ]
        showResults = false
    }
    
    // MARK: - 🧠 AI Generation Engine 🧠
    
    // Dynamic generation logic that simulates an AI response
    var generatedRecommendations: [Recommendation] = []
    
    @MainActor
    func generateReport() async {
        self.isGenerating = true
        
        // 1. Simulate AI Thinking Latency (adds realism)
        try? await Task.sleep(nanoseconds: 1_500_000_000) // 1.5 seconds
        
        // 2. Call the Local Intelligence Engine
        // In a future version, this would be replaced by:
        // let result = await FoundationModel.generate(...)
        self.generatedRecommendations = LocalIntelligenceEngine.generate(
            mbti: selectedMBTI ?? .INTJ,
            gcses: gcses,
            interests: careerGoals
        )
        
        // 3. Complete
        withAnimation {
            self.showResults = true
            self.isGenerating = false
        }
    }
}

// MARK: - 4. MAIN CONTAINER VIEW

struct ContentView: View {
    @AppStorage("hasCompletedOnboarding") var hasCompletedOnboarding: Bool = false
    
    var body: some View {
        Group {
            if hasCompletedOnboarding {
                MainAppView()
                    .transition(.opacity.animation(.easeOut(duration: 0.35)))
            } else {
                OnboardingParentView()
            }
        }
    }
}

struct MainAppView: View {
    @State private var viewModel = PathfinderViewModel()
    
    var body: some View {
        if viewModel.showResults {
            DashboardView(viewModel: viewModel)
                .transition(.opacity)
        } else {
            NavigationSplitView {
                List(selection: $viewModel.selection) {
                    Label("1. About You", systemImage: "person.circle").tag(0)
                    Label("2. Academics (GCSE)", systemImage: "graduationcap").tag(1)
                    Label("3. Aspirations & Hobbies", systemImage: "star").tag(2)
                }
                .navigationTitle("A-Level Pathfinder")
                .listStyle(.sidebar)
            } detail: {
                if let selection = viewModel.selection {
                    switch selection {
                    case 0: InputAboutView(viewModel: viewModel)
                    case 1: InputAcademicsView(viewModel: viewModel)
                    case 2: InputAspirationsView(viewModel: viewModel)
                    default: Text("Select a step to begin.")
                    }
                } else {
                    Text("Select a step to begin.")
                }
            }
            .accentColor(.indigo)
        }
    }
}

// MARK: - 5. INPUT VIEWS

struct PrimaryButtonStyle: ButtonStyle {
    var isEnabled: Bool
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline).fontWeight(.bold)
            .frame(maxWidth: .infinity).padding()
            .background(isEnabled ? Color.indigo : Color.gray.opacity(0.3))
            .foregroundColor(isEnabled ? .white : .gray)
            .cornerRadius(12)
            .shadow(color: isEnabled ? Color.indigo.opacity(0.3) : Color.clear, radius: 5, x: 0, y: 3)
            .scaleEffect(configuration.isPressed ? 0.98 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: isEnabled)
    }
}

struct InputAboutView: View {
    @Bindable var viewModel: PathfinderViewModel
    
    var body: some View {
        VStack {
            Form {
                Section("Basic Information") {
                    Picker("Gender", selection: $viewModel.gender) {
                        Text("Female").tag("Female"); Text("Male").tag("Male"); Text("Non-binary").tag("Non-binary")
                    }
                    TextField("Country / Region (e.g. UK)", text: $viewModel.hometown).autocorrectionDisabled()
                    Picker("First Language", selection: $viewModel.firstLanguage) {
                        Text("English").tag("English"); Text("Mandarin").tag("Mandarin"); Text("Cantonese").tag("Cantonese")
                        Text("Spanish").tag("Spanish"); Text("French").tag("French"); Text("German").tag("German")
                        Text("Japanese").tag("Japanese"); Text("Korean").tag("Korean"); Text("Hindi").tag("Hindi")
                        Text("Arabic").tag("Arabic"); Text("Portuguese").tag("Portuguese"); Text("Russian").tag("Russian")
                        Text("Italian").tag("Italian"); Text("Other").tag("Other")
                    }
                }
                
                Section("MBTI Personality (Your Thinking Style)") {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("What is this and why does it matter?")
                            .font(.headline)
                            .foregroundColor(.primary)
                        Text("The Myers-Briggs Type Indicator (MBTI) decodes how you perceive the world. We use this to match you with subjects that align with your natural cognitive strengths.")
                            .font(.caption).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.vertical, 8)
                    
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 15)], spacing: 15) {
                        ForEach(MBTIType.allCases) { type in
                            Button(action: { withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { viewModel.selectedMBTI = type } }) {
                                VStack(spacing: 12) {
                                    ZStack {
                                        Circle().fill(viewModel.selectedMBTI == type ? Color.white.opacity(0.2) : Color.indigo.opacity(0.1)).frame(width: 50, height: 50)
                                        Image(systemName: type.iconName).font(.title2).foregroundColor(viewModel.selectedMBTI == type ? .white : .indigo)
                                    }
                                    VStack(spacing: 2) {
                                        Text(type.rawValue).font(.headline).fontWeight(.bold)
                                        Text(type.description).font(.caption).fontWeight(.medium).opacity(0.8)
                                    }
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 20)
                                .background(RoundedRectangle(cornerRadius: 16).fill(viewModel.selectedMBTI == type ? Color.indigo : Color(uiColor: .secondarySystemBackground)))
                                .overlay(RoundedRectangle(cornerRadius: 16).stroke(viewModel.selectedMBTI == type ? Color.indigo : Color.clear, lineWidth: 2))
                                .foregroundColor(viewModel.selectedMBTI == type ? .white : .primary)
                                .shadow(color: viewModel.selectedMBTI == type ? Color.indigo.opacity(0.3) : Color.clear, radius: 8, x: 0, y: 4)
                                .scaleEffect(viewModel.selectedMBTI == type ? 1.02 : 1.0)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 10)
                }
            }
            Button("Next Step") { withAnimation { viewModel.selection = 1 } }
                .buttonStyle(PrimaryButtonStyle(isEnabled: viewModel.isAboutValid))
                .disabled(!viewModel.isAboutValid).padding()
        }
        .navigationTitle("1. About You")
    }
}

struct InputAcademicsView: View {
    @Bindable var viewModel: PathfinderViewModel
    @State private var showSubjectSelection = false
    let subjectTip = SubjectManagementTip()
    
    var body: some View {
        VStack {
            List {
                Section {
                    if viewModel.gcses.isEmpty {
                        ContentUnavailableView("No Subjects Selected", systemImage: "book.closed", description: Text("Tap 'Manage Subjects' to add your GCSEs."))
                    } else {
                        ForEach($viewModel.gcses) { $subject in
                            VStack(alignment: .leading, spacing: 5) {
                                HStack {
                                    Text(subject.name).fontWeight(.medium)
                                    Spacer()
                                    Text("Grade: \(Int(subject.grade))").font(.system(.body, design: .monospaced)).fontWeight(.bold).foregroundStyle(.indigo)
                                }
                                Slider(value: $subject.grade, in: 1...9, step: 1) { Text("Grade") } minimumValueLabel: { Text("1").font(.caption2).foregroundColor(.secondary) } maximumValueLabel: { Text("9").font(.caption2).foregroundColor(.secondary) }.tint(.indigo)
                            }
                            .padding(.vertical, 4)
                        }
                        .onDelete { indexSet in viewModel.gcses.remove(atOffsets: indexSet) }
                    }
                } header: {
                    HStack { Text("Your Predicted Grades"); Spacer(); Text("\(viewModel.gcses.count) Subjects").font(.caption).foregroundStyle(.secondary) }
                }
                Section {
                    Button(action: { showSubjectSelection = true; subjectTip.invalidate(reason: .actionPerformed) }) {
                        HStack { Image(systemName: "checklist"); Text("Add / Remove Subjects").fontWeight(.medium) }.foregroundColor(.indigo)
                    }
                    .popoverTip(subjectTip, arrowEdge: .top)
                } footer: { Text("Select the subjects you are currently studying. Default grade is set to 7.") }
            }
            Button("Next Step") { withAnimation { viewModel.selection = 2 } }
                .buttonStyle(PrimaryButtonStyle(isEnabled: true)).padding()
        }
        .navigationTitle("2. Academics (GCSE)")
        .sheet(isPresented: $showSubjectSelection) { SubjectSelectionView(viewModel: viewModel) }
    }
}

struct SubjectSelectionView: View {
    @Bindable var viewModel: PathfinderViewModel
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(allGCSESubjects, id: \.self) { subjectName in
                    HStack {
                        Text(subjectName).foregroundStyle(.primary)
                        Spacer()
                        Image(systemName: viewModel.gcses.contains(where: { $0.name == subjectName }) ? "checkmark.circle.fill" : "circle")
                            .font(.title2)
                            .foregroundColor(viewModel.gcses.contains(where: { $0.name == subjectName }) ? .indigo : .gray.opacity(0.3))
                    }
                    .contentShape(Rectangle())
                    .onTapGesture { toggleSubject(subjectName) }
                }
            }
            .navigationTitle("Select Subjects").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
    
    func toggleSubject(_ name: String) {
        if let index = viewModel.gcses.firstIndex(where: { $0.name == name }) {
            withAnimation { _ = viewModel.gcses.remove(at: index) }
        } else {
            withAnimation { viewModel.gcses.append(GCSESubject(name: name, grade: 7)) }
        }
    }
}

struct InputAspirationsView: View {
    @Bindable var viewModel: PathfinderViewModel
    
    var body: some View {
        VStack {
            Form {
                Section("Top 3 Career Interests") {
                    Text("Your A-Level choices should align with future university courses.").font(.caption).foregroundColor(.secondary)
                    TextField("(Option 1) e.g., Maths", text: $viewModel.careerGoals[0])
                    TextField("(Option 2) e.g., Computer Science (Optional)", text: $viewModel.careerGoals[1])
                    TextField("(Option 3) e.g., Biomedical Engineering (Optional)", text: $viewModel.careerGoals[2])
                }
                Section("Extracurricular Activities") {
                    Text("Activities show universities your soft skills.").font(.caption).foregroundColor(.secondary)
                    TextEditor(text: $viewModel.activities).frame(height: 120)
                        .overlay(viewModel.activities.isEmpty ? Text("e.g., Debate Club, School Orchestra...").foregroundColor(.gray.opacity(0.6)).allowsHitTesting(false).padding(.all, 8).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading) : nil)
                }
            }
            
            // 🌟 UPDATED: Async Button for AI Generation
            Button(action: {
                Task { await viewModel.generateReport() }
            }) {
                ZStack {
                    if viewModel.isGenerating {
                        ProgressView().tint(.white)
                    } else {
                        Text("Generate Pathfinder Report").fontWeight(.bold)
                    }
                }
                .frame(maxWidth: .infinity).padding()
                .background(viewModel.isAspirationsValid ? Color.indigo : Color.gray.opacity(0.3))
                .foregroundColor(viewModel.isAspirationsValid ? .white : .gray)
                .cornerRadius(12)
                .shadow(color: viewModel.isAspirationsValid ? Color.indigo.opacity(0.3) : Color.clear, radius: 5, x: 0, y: 3)
            }
            .buttonStyle(.plain)
            .disabled(!viewModel.isAspirationsValid || viewModel.isGenerating)
            .padding()
        }
        .navigationTitle("3. Aspirations & Hobbies")
    }
}

// MARK: - 6. DASHBOARD VIEW

struct DashboardView: View {
    @Bindable var viewModel: PathfinderViewModel
    
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground).edgesIgnoringSafeArea(.all)
            VStack(alignment: .leading, spacing: 20) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(spacing: 8) {
                            Image(systemName: "location.north.circle.fill").font(.title).foregroundStyle(.indigo)
                            HStack(spacing: 0) {
                                Text("A-Level ").font(.system(.largeTitle, design: .rounded)).fontWeight(.bold).foregroundStyle(.primary)
                                Text("Pathfinder").font(.system(.largeTitle, design: .rounded)).fontWeight(.black).foregroundStyle(.indigo)
                            }
                        }
                        Text("Based on your \(viewModel.selectedMBTI?.description ?? "Student") profile and GCSE results.").foregroundColor(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 12) {
                        Button(action: { withAnimation { viewModel.showResults = false } }) {
                            HStack { Image(systemName: "pencil"); Text("Edit Inputs") }
                                .padding(.horizontal, 16).padding(.vertical, 10)
                                .background(Color.indigo.opacity(0.1)).foregroundColor(.indigo).cornerRadius(10)
                        }
                        Button(action: { withAnimation { viewModel.resetData() } }) {
                            HStack { Image(systemName: "arrow.counterclockwise"); Text("Start Over") }
                                .padding(.horizontal, 16).padding(.vertical, 10)
                                .background(Color.red.opacity(0.1)).foregroundColor(.red).cornerRadius(10)
                        }
                    }
                }
                .padding(.horizontal, 40).padding(.top, 40)
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 30) {
                        ForEach(viewModel.generatedRecommendations) { rec in
                            RecommendationCard(rec: rec) { viewModel.selectedRecommendation = rec }
                        }
                    }
                    .padding(.horizontal, 40).padding(.bottom, 40)
                }
            }
        }
        .sheet(item: $viewModel.selectedRecommendation) { rec in DetailView(rec: rec, viewModel: viewModel) }
    }
}

struct RecommendationCard: View {
    let rec: Recommendation
    let action: () -> Void
    @MainActor private func generateShareImage() -> Image {
        let renderer = ImageRenderer(content: ResultSnapshotView(rec: rec))
        renderer.scale = 2.0
        if let uiImage = renderer.uiImage { return Image(uiImage: uiImage) }
        return Image(systemName: "xmark.circle")
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                CircularProgressView(progress: Double(rec.matchScore) / 100.0, score: rec.matchScore).frame(width: 50, height: 50)
                Spacer()
                ShareLink(item: generateShareImage(), preview: SharePreview("Pathfinder Strategy: \(rec.title)", image: generateShareImage())) {
                    Image(systemName: "square.and.arrow.up").font(.title3).foregroundColor(.indigo)
                        .padding(8).background(Color.indigo.opacity(0.1)).clipShape(Circle())
                }
            }
            Divider()
            Text(rec.title).font(.title2.bold())
            VStack(alignment: .leading, spacing: 8) {
                ForEach(rec.subjects, id: \.self) { subject in
                    HStack { Image(systemName: "graduationcap.fill").foregroundColor(.indigo); Text(subject) }
                }
            }
            .padding(.vertical, 5)
            Spacer()
            HStack(alignment: .top) { Image(systemName: "arrow.right.circle.fill").foregroundColor(.secondary); Text(rec.mainCareerFit).font(.caption).foregroundColor(.secondary).lineLimit(2) }
            Button(action: action) {
                Text("Analyze Deep Dive").fontWeight(.semibold).frame(maxWidth: .infinity).padding(10)
                    .background(Color.indigo).foregroundColor(.white).cornerRadius(10)
            }
        }
        .padding(25).frame(width: 320, height: 550)
        .background(Color(uiColor: .systemBackground)).cornerRadius(20)
        .shadow(color: Color.black.opacity(0.15), radius: 15, x: 0, y: 10)
    }
}

struct ResultSnapshotView: View {
    let rec: Recommendation
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                VStack(alignment: .leading) {
                    Text("A-LEVEL PATHFINDER").font(.caption.bold()).tracking(2).foregroundColor(.white.opacity(0.8))
                    Text("Strategy Report").font(.title2.bold()).foregroundColor(.white)
                }
                Spacer()
                Image(systemName: "graduationcap.circle.fill").font(.system(size: 40)).foregroundColor(.white)
            }
            .padding().background(Color.indigo)
            
            VStack(alignment: .leading, spacing: 15) {
                Text(rec.title).font(.title.bold()).foregroundColor(.black)
                Divider()
                HStack {
                    VStack(alignment: .leading) { Text("MATCH SCORE").font(.caption).foregroundColor(.secondary); Text("\(rec.matchScore)%").font(.system(size: 40, weight: .black)).foregroundColor(.indigo) }
                    Spacer()
                    VStack(alignment: .trailing) { Text("CAREER GOAL").font(.caption).foregroundColor(.secondary); Text(rec.mainCareerFit).font(.headline).foregroundColor(.primary) }
                }
                Divider()
                Text("RECOMMENDED SUBJECTS").font(.caption.bold()).foregroundColor(.secondary)
                HStack {
                    ForEach(rec.subjects.prefix(3), id: \.self) { subject in
                        Text(subject).font(.caption.bold()).padding(6).background(Color.indigo.opacity(0.1)).foregroundColor(.indigo).cornerRadius(4)
                    }
                }
            }
            .padding(20)
            HStack { Text("Generated by A-Level Pathfinder").font(.caption2).foregroundColor(.secondary); Spacer(); Image(systemName: "qrcode").foregroundColor(.secondary) }
            .padding().background(Color(uiColor: .secondarySystemBackground))
        }
        .frame(width: 350).background(Color.white).cornerRadius(20)
    }
}

struct CircularProgressView: View {
    let progress: Double
    let score: Int
    var body: some View {
        ZStack {
            Circle().stroke(Color.gray.opacity(0.2), lineWidth: 6)
            Circle().trim(from: 0, to: progress).stroke(Color.indigo, style: StrokeStyle(lineWidth: 6, lineCap: .round)).rotationEffect(.degrees(-90))
            Text("\(score)").font(.subheadline.bold())
        }
    }
}

struct DetailView: View {
    let rec: Recommendation
    @Bindable var viewModel: PathfinderViewModel
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 30) {
                    Text("The Connection Map").font(.title2.bold())
                    
                    // Dynamic Connection Items
                    ConnectionItem(from: "Your Academics", to: rec.subjects.first ?? "Core Subject", reason: "Leveraging your strongest GCSE grades.")
                    ConnectionItem(from: "Your Personality", to: rec.subjects.last ?? "Choice", reason: "Matching your \(viewModel.selectedMBTI?.rawValue ?? "MBTI") thinking style.")
                    
                    Divider()
                    
                    Text("Career Pathway Analysis").font(.title2.bold())
                    // Dynamic Career Fit
                    ForEach(viewModel.careerGoals.filter{!$0.isEmpty}, id: \.self) { goal in
                        CareerFitRow(career: goal, stars: Int.random(in: 3...5), comment: "This combination provides a strong foundation for \(goal).")
                    }
                    
                    Button(action: { dismiss() }) { Text("Save & Close").bold().frame(maxWidth: .infinity).padding().background(Color.indigo).foregroundColor(.white).cornerRadius(12) }.padding(.top, 20)
                }
                .padding()
            }
            .navigationTitle("Analysis: \(rec.title)").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Dismiss", systemImage: "xmark.circle.fill") { dismiss() } } }
        }
    }
}

struct ConnectionItem: View {
    let from: String, to: String, reason: String
    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            VStack { Circle().fill(Color.indigo).frame(width: 12, height: 12); Rectangle().fill(Color.indigo.opacity(0.3)).frame(width: 2, height: 60); Circle().stroke(Color.indigo, lineWidth: 2).frame(width: 12, height: 12) }
            VStack(alignment: .leading, spacing: 8) { Text(from).font(.headline); Text("Reason: \(reason)").font(.callout).foregroundColor(.secondary).padding(8).background(Color.yellow.opacity(0.1)).cornerRadius(6); Text("Aligns with: \(to)").font(.headline).foregroundColor(.indigo) }
        }
    }
}

struct CareerFitRow: View {
    let career: String, stars: Int, comment: String
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(career).font(.title3.bold())
            HStack { ForEach(1...5, id: \.self) { index in Image(systemName: index <= stars ? "star.fill" : "star").foregroundColor(index <= stars ? .orange : .gray.opacity(0.5)) }; Text("(\(stars)/5 Fit)").font(.subheadline).foregroundColor(.secondary) }
            Text(comment).font(.callout).padding().background(Color(uiColor: .secondarySystemBackground)).cornerRadius(10)
        }
    }
}

// MARK: - 7. ONBOARDING & HELPER VIEWS

struct OnboardingParentView: View {
    @AppStorage("hasCompletedOnboarding") var hasCompletedOnboarding: Bool = false
    @State private var currentPage = 0
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground).edgesIgnoringSafeArea(.all)
            TabView(selection: $currentPage) {
                OnboardingWelcomePage().tag(0)
                OnboardingPageView(imageName: "chart.xyaxis.line", title: "Data-Driven Decisions", description: "Synthesize your predicted grades and MBTI.", accentColor: .blue).tag(1)
                OnboardingPageView(imageName: "map.fill", title: "Your Personal Roadmap", description: "Receive tailored subject combinations.", accentColor: .red).tag(2)
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            VStack {
                Spacer()
                HStack(spacing: 8) { ForEach(0..<3) { index in Circle().fill(currentPage == index ? Color.primary : Color.secondary.opacity(0.3)).frame(width: 8, height: 8) } }.padding(.bottom, 20)
                VStack(spacing: 20) {
                    if currentPage == 2 {
                        Button(action: { withAnimation { hasCompletedOnboarding = true } }) {
                            Text("Start My Pathfinder Journey").font(.headline.bold()).frame(minWidth: 200, maxWidth: 360).padding().background(Color.indigo).foregroundColor(.white).cornerRadius(15).shadow(color: Color.indigo.opacity(0.4), radius: 8, x: 0, y: 4)
                        }
                    } else { Button("Skip to Start") { withAnimation { hasCompletedOnboarding = true } }.font(.subheadline).foregroundColor(.secondary).padding() }
                }
                .padding(.bottom, 50)
            }
        }
    }
}

struct OnboardingWelcomePage: View {
    @State private var animateIcon = false
    var body: some View {
        VStack(spacing: 0) {
            Spacer()
            VStack(spacing: 20) {
                ZStack {
                    Circle().fill(Color.indigo.opacity(0.15)).frame(width: 160, height: 160).scaleEffect(animateIcon ? 1.1 : 1.0).animation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true), value: animateIcon)
                    Image(systemName: "location.north.circle.fill").resizable().aspectRatio(contentMode: .fit).frame(width: 120, height: 120).foregroundStyle(.indigo).background(Color.white.clipShape(Circle())).shadow(color: .indigo.opacity(0.3), radius: 15, x: 0, y: 10)
                }
                .onAppear { animateIcon = true }
                Text("Welcome to\nA-Level Pathfinder").font(.system(.largeTitle, design: .rounded)).fontWeight(.heavy).multilineTextAlignment(.center)
                Text("Your future, your choices. No pressure.").font(.title3).fontWeight(.medium).foregroundStyle(.secondary)
            }
            .padding(.bottom, 40)
            VStack(alignment: .leading, spacing: 30) {
                FeatureRow(icon: "person.fill.viewfinder", color: .indigo, title: "Take Control", description: "Find your own path beyond just grades.")
                FeatureRow(icon: "brain.head.profile", color: .purple, title: "MBTI Powered", description: "Decode which subjects click with your brain.")
                FeatureRow(icon: "star.fill", color: .red, title: "Thrive", description: "Find A-Levels where you'll truly shine.")
            }
            .padding(.horizontal, 20)
            Spacer(); Spacer()
        }
        .padding().padding(.bottom, 120)
    }
}

struct FeatureRow: View {
    let icon: String; let color: Color; let title: String; let description: String
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Image(systemName: icon).font(.title2).foregroundStyle(color).frame(width: 30).padding(.top, 2)
            VStack(alignment: .leading, spacing: 5) { Text(title).font(.headline); Text(description).font(.body).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }
        }
    }
}

struct OnboardingPageView: View {
    let imageName: String; let title: String; let description: String; let accentColor: Color
    var body: some View {
        VStack(spacing: 30) {
            ZStack { Circle().fill(accentColor.opacity(0.1)).frame(width: 180, height: 180); Image(systemName: imageName).resizable().aspectRatio(contentMode: .fit).frame(width: 90, height: 90).foregroundColor(accentColor) }.padding(.top, 40)
            VStack(spacing: 15) { Text(title).font(.system(size: 32, weight: .bold)).multilineTextAlignment(.center); Text(description).font(.title3).foregroundColor(.secondary).multilineTextAlignment(.center).padding(.horizontal, 30).fixedSize(horizontal: false, vertical: true) }
        }
        .padding().padding(.bottom, 120)
    }
}

// MARK: - 🧠 LOCAL INTELLIGENCE ENGINE (v3.0 - Degree Focused) 🧠
// Simulates an AI Career Advisor.
// Maps Grades + Personality -> A-Level Combinations -> Likely University Degrees.

struct LocalIntelligenceEngine {
    
    static func generate(mbti: MBTIType, gcses: [GCSESubject], interests: [String]) -> [Recommendation] {
        var recs: [Recommendation] = []
        
        // --- DATA PRE-PROCESSING ---
        let topSubjects = gcses.filter { $0.grade >= 6 }.sorted { $0.grade > $1.grade }
        let topNames = topSubjects.map { $0.name }
        let rawInterests = interests.joined(separator: " ").lowercased()
        
        // Helper to check subject presence
        func has(_ sub: String) -> Bool { return topNames.contains(sub) }
        
        // --- 1️⃣ OPTION A: STRENGTH-BASED DEGREE ---
        // Logic: Look at top 3 grades -> Determine best traditional degree.
        var subA = Array(topNames.prefix(3))
        if subA.count < 3 { subA = ["Mathematics", "Business Studies", "Media Studies"] } // Fallback
        
        // Dynamic Title Logic for A
        var titleA = "General Studies"
        let sA = subA.joined()
        if sA.contains("Math") && sA.contains("Phys") { titleA = "Engineering / Physics" }
        else if sA.contains("Bio") && sA.contains("Chem") { titleA = "Medicine / Biomedical Sci" }
        else if sA.contains("Math") && sA.contains("Comp") { titleA = "Computer Science / AI" }
        else if sA.contains("Hist") || sA.contains("Eng") { titleA = "Law / Politics" }
        else if sA.contains("Art") { titleA = "Architecture / Fine Art" }
        else if sA.contains("Econ") || sA.contains("Bus") { titleA = "Finance & Management" }
        
        recs.append(Recommendation(
            title: "Degree Path: \(titleA)",
            subjects: subA,
            matchScore: 98,
            careerPath: "Direct professional entry based on your strongest academic performance.",
            keyReasons: ["Leverages your Grade \(Int(topSubjects.first?.grade ?? 9)) in \(subA.first ?? "").", "Meets entry requirements for top UK universities."],
            description: "Based strictly on your highest GCSE grades, this combination maximizes your UCAS points and positions you strongly for a competitive degree in \(titleA).",
            mainCareerFit: titleA
        ))
        
        // --- 2️⃣ OPTION B: PERSONALITY-BASED DEGREE (MBTI) ---
        // Logic: MBTI Group -> Ideal Subject Mix -> Ideal Degree
        var subB: [String] = []
        var titleB = ""
        let group = mbti.color // Proxy for MBTI Group
        
        if group == .indigo { // Analysts (INTJ, etc.) -> STEM
            titleB = "Data Science & AI"
            subB = ["Mathematics", "Further Maths", "Computer Science"]
            if !has("Comp") { subB[2] = "Physics" }
        } else if group == .blue { // Sentinels (ISTJ, etc.) -> Order/Facts
            titleB = "Accounting & Finance"
            subB = ["Mathematics", "Economics", "Business Studies"]
        } else if group == .green { // Diplomats (INFJ, etc.) -> People/Ideas
            titleB = "Psychology & Sociology"
            subB = ["Psychology", "Sociology", "Biology"] // Bio is needed for Psych
        } else { // Explorers (ISTP, etc.) -> Hands-on/Action
            titleB = "Product Design & Eng"
            subB = ["Design & Technology", "Physics", "Mathematics"]
        }
        
        recs.append(Recommendation(
            title: "Degree Path: \(titleB)",
            subjects: subB,
            matchScore: 94,
            careerPath: "Careers suiting the \(mbti.rawValue) mindset.",
            keyReasons: ["Aligns with your '\(mbti.description)' thinking style.", "Optimized for cognitive engagement."],
            description: "Your personality type suggests you thrive in fields requiring \(group == .indigo ? "complex logic" : "human understanding"). This pathway leads directly to \(titleB).",
            mainCareerFit: titleB
        ))
        
        // --- 3️⃣ OPTION C: INTEREST-BASED DEGREE ---
        // Logic: Keyword mapping -> Degree
        var subC: [String] = []
        var titleC = ""
        
        if rawInterests.contains("med") || rawInterests.contains("doc") {
            titleC = "Medicine / Dentistry"
            subC = ["Chemistry", "Biology", "Mathematics"]
        } else if rawInterests.contains("art") || rawInterests.contains("des") {
            titleC = "Creative Arts / Design"
            subC = ["Art & Design", "Media Studies", "English Literature"]
        } else if rawInterests.contains("comp") || rawInterests.contains("tech") {
            titleC = "Software Engineering"
            subC = ["Computer Science", "Mathematics", "Physics"]
        } else if rawInterests.contains("law") || rawInterests.contains("pol") {
            titleC = "Law (LLB)"
            subC = ["History", "English Literature", "Politics"] // Simulated Politics if not in list
        } else {
            titleC = "Business Management"
            subC = ["Business Studies", "Economics", "Mathematics"]
        }
        
        // Sanity check: Ensure valid subjects from user list where possible
        if !has("Politics") && subC.contains("Politics") { subC[2] = "Sociology" }
        
        recs.append(Recommendation(
            title: "Degree Path: \(titleC)",
            subjects: subC,
            matchScore: 92,
            careerPath: "Directly aligned with your stated goal: '\(interests.first ?? "Career")'.",
            keyReasons: ["Contains non-negotiable prerequisites.", "Standard industry route."],
            description: "You mentioned an interest in this field. This is the standard 'Golden Trio' of subjects required to apply for \(titleC) at Russell Group universities.",
            mainCareerFit: titleC
        ))
        
        // --- 4️⃣ OPTION D: THE FACILITATOR (Safe Bet) ---
        // Logic: High prestige subjects -> PPE or Economics
        // PPE (Politics, Philosophy, Economics) is very famous in UK.
        var subD = ["Mathematics", "History", "Economics"]
        if !has("Economics") { subD[2] = "Geography" }
        if !has("History") { subD[1] = "English Literature" }
        
        recs.append(Recommendation(
            title: "Degree Path: PPE / Economics",
            subjects: subD,
            matchScore: 88,
            careerPath: "Politics, Banking, Civil Service",
            keyReasons: ["Based on 'Facilitating Subjects'.", "Keeps options open for top-tier unis."],
            description: "This combination focuses on 'Facilitating Subjects'—the ones most respected by admissions tutors. It strongly supports applications for PPE (Philosophy, Politics, Economics) or Law.",
            mainCareerFit: "PPE / Law / Economics"
        ))
        
        // --- 5️⃣ OPTION E: THE MODERN HYBRID (Liberal Arts) ---
        // Logic: Mix of everything.
        let s1 = has("Mathematics") ? "Mathematics" : "Computer Science"
        let s2 = has("English Literature") ? "English Literature" : "History"
        let s3 = has("Art & Design") ? "Art & Design" : "Media Studies"
        
        recs.append(Recommendation(
            title: "Degree Path: Liberal Arts",
            subjects: [s1, s2, s3],
            matchScore: 85,
            careerPath: "Journalism, UX Design, Policy",
            keyReasons: ["Interdisciplinary approach.", "Develops both analytical and creative skills."],
            description: "For the student who refuses to choose between Arts and Sciences. This 'Liberal Arts' combination builds a diverse portfolio suited for the modern, changing job market.",
            mainCareerFit: "Liberal Arts / Digital Media"
        ))
        
        return recs
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewInterfaceOrientation(.landscapeLeft)
            .previewDevice("iPad Pro (11-inch) (4th generation)")
    }
}
